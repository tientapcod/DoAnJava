package server.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import bean.FriendInfo;

public class FriendsDAO {
	private Connection con;
	public FriendsDAO() {
		Properties pr=new Properties();
		try {
			pr.load(new FileInputStream("configdb.properties"));
			Class.forName(pr.getProperty("classForName"));
			String dburl = pr.getProperty("dburl");
			con = DriverManager.getConnection(dburl);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public ArrayList<FriendInfo> getAllFriends(String userName)
	{
		ArrayList<FriendInfo> list=new ArrayList<FriendInfo>();
		FriendInfo fr;
		Statement stmt;
		try {
			stmt = con.createStatement();
			String sql= "select UserFriend,Name from Friends join Users on Friends.UserFriend=Users.UserName and Friends.Users='"+userName+"'";
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				fr=new FriendInfo();
				fr.setUserName(rs.getString(1).trim());
				fr.setName(rs.getString(2).trim());
				list.add(fr);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public boolean addFriend(String userName1,String userName2)
	{
		String sql="insert into Friends values ('"+userName1+"','"+userName2+"')";
		try {
			return con.createStatement().executeUpdate(sql)>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;
		}
	}
}

package server.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.swing.JOptionPane;

import bean.User;



public class ChatUserDAO {
	private Connection con;
	
	public ChatUserDAO() {
		Properties pr=new Properties();	
		try {
			pr.load(new FileInputStream("configdb.properties"));
			Class.forName(pr.getProperty("classForName"));
			String dburl = pr.getProperty("dburl");
			con = DriverManager.getConnection(dburl);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public User getUser(String userName) {
		User u = null; 
		Statement stmt;
		try {
			stmt = con.createStatement();
			System.out.println(userName);
			String sql = "select IP, UserName, Name, PassWord, Port, Email from Users where UserName='"+userName+"'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				u = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return u;
	}
	public boolean checkUser(String userName) {
		String sql = "select * from Users where UserName='" + userName+"'";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);	
			return rs.next();
		} catch (Exception e) {
			System.out.println("Lỗi checkUser " + e);
		}
		return false;
	}

	public boolean setIpAndPort(String userName, String ip,int port) {
		String sql = "update Users set IP=?,Port=? where UserName=?";
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ip);
			pstmt.setInt(2, port);
			pstmt.setString(3, userName);
			return pstmt.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}
//	public void addUser(String userName,String pass,String ten,String email)throws SQLException
//	{		
//		String sql="insert into Users values ('"+userName+"','','','"+email+"','"+pass+"',N'"+ten+"')";
//		if(con.createStatement().executeUpdate(sql)==0)
//		{
//			JOptionPane.showMessageDialog(null,"Tên đăng nhập đã tồn tại");
//		}
//		else
//		{		
//			JOptionPane.showMessageDialog(null,"Đăng ký thành công với tên: "+userName);
//			
//		}
//	}
		
	public String findPassword(String userName,String email)
	{
		String sql="select PassWord from Users where UserName='"+userName+"' and Email='"+email+"' ";
		String pass=null;
		try
		{
		ResultSet rs=con.createStatement().executeQuery(sql);
		while(rs.next()){
			pass=rs.getString("PassWord").trim();
		}
		}
		catch(Exception e)
		{
			return pass;
		}
		return pass;
	}
	public boolean register(String username, String name, String pass,
			String email) {
		String sql = "insert into Users(UserName,PassWord,Email,Name) values('"+username+"','"+pass+"','"+email+"','"+name+"')";
		try {
			if(con.createStatement().executeUpdate(sql) > 0){
				return true;
			}
		} catch (SQLException e) {
			System.out.println("loi register " + e);
		}
		return false;
	}
}

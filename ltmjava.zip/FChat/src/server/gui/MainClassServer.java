package server.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import bean.Client;
import server.bo.ProcessServer;


public class MainClassServer extends JFrame implements ActionListener{
	private JButton btExit;
	public MainClassServer() {
	Box b=Box.createVerticalBox();
	b.add(new JLabel("Server is starting..."));
	b.add(Box.createVerticalStrut(10));
	b.add(btExit=new JButton("shutdown server"));
	add(b);
	btExit.addActionListener(this);
	setSize(400,300);
	setLocationRelativeTo(null);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) throws IOException {
		new MainClassServer().setVisible(true);
		ArrayList<Client> listClient=new ArrayList<Client>();
		ArrayList<Client> listClientSentFile=new ArrayList<>();
		try{
			ServerSocket svr = new ServerSocket(9999);
			while(true){
				Socket soc = svr.accept();
				ProcessServer pr = new ProcessServer(soc, listClient, listClientSentFile);
				Thread thread = new Thread(pr);
				thread.start();
			}
			
		}catch(Exception e){
			JOptionPane.showMessageDialog(null, "Cổng 9999 đang bận! Vui lòng thử lại sau!");
			System.exit(0);
		}		
	}
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource()==btExit){
			System.exit(0);
		}
	}
}

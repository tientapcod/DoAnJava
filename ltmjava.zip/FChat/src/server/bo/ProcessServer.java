package server.bo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import bean.Client;
import bean.AddFriendRequest;
import bean.AddFriendRespose;
import bean.AlertAddFriend;
import bean.DeleteRequest;
import bean.FriendInfo;
import bean.FriendListRepose;
import bean.FriendListRequest;
import bean.LoginRequest;
import bean.LoginRespose;
import bean.Message;
import bean.RegisterRequest;
import bean.ResetPassRequest;
import bean.ResetPassRespose;
import bean.StartUDPOfClientRequest;
import bean.StartUDPOfClientRespose;
import bean.StartUDPOfServerRepose;
import bean.StartUDPOfServerRequest;
import bean.StopSendFromClient;
import bean.StopSendFromServer;
import bean.User;
import server.dao.ChatUserDAO;
import server.dao.FriendsDAO;

/**
 * lớp xử lý của server
 * 
 * */
public class ProcessServer implements Runnable {
	private Socket soc;
	private ChatUserDAO cud;
	private FriendsDAO fd;
	private LoginRequest lrq;
	private LoginRespose lrp;
	private User u;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private ArrayList<Client> listClient;
	private Client client;
	private Message ms;
	private StartUDPOfClientRespose sudocrp;
	private StartUDPOfClientRequest sudocrq;
	private StartUDPOfServerRequest suosr;
	private Object obj;
	private ObjectOutputStream oos2;
	public ProcessServer(Socket soc, ArrayList<Client> listClient,
			ArrayList<Client> listClientSentFile) {
		this.soc = soc;
		this.listClient = listClient;
	}

	public ArrayList<Client> getListClient() {
		return listClient;
	}

	public void setListClient(ArrayList<Client> listClient) {
		this.listClient = listClient;
	}

	private void clientLogOut(DeleteRequest dr, ArrayList<Client> listClient) {
		try{
			for (Client cl : listClient) {
				if (cl.getUserName().equals(dr.getUserName())
						&& cl.getPassWord().equals(dr.getPassWord())) {
					listClient.remove(cl);
				}
			}
		}
		catch(Exception e)
		{
			
		}
		
	}

	private Socket getSocketInClient(ArrayList<Client> listClients,
			Client client) {
		for (Client cl : listClients) {
			if (client.getUserName().equals(cl.getUserName())) {
				return cl.getSoc();
			}

		}
		return null;
	}

	private Socket getSocketByUserName(ArrayList<Client> listClients,
			String username) {
		System.out.println(username);
		for (Client cl : listClients) {
			if (username.equals(cl.getUserName())) {
				return cl.getSoc();
			}

		}
		return null;
	}

	private boolean clientIsCurrent(ArrayList<Client> listClients, Client client) {
		for (Client cl : listClients) {
			if (client.getUserName().equals(cl.getUserName())) {
				return true;
			}

		}
		return false;
	}

	private boolean removeClient(ArrayList<Client> listClients, Client client) {
		for (Client cl : listClients) {
			if (client.getUserName().equals(cl.getUserName())) {
				try {
					cl.getSoc().close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				listClients.remove(cl);
				return true;
			}

		}
		return false;
	}

	/*
	 * Nhận đối tượng yêu cầu Kiểm tra trong danh sách có người nhận hay không
	 * Nêu không có thì gửi về không có người nhận hợp lệ Nếu có thì gửi yêu cầu
	 * mở cổng về người nhận* Đợi trả lời của người nhận* Nếu người nhận chấp
	 * nhận nhận file thì gửi về người gửi ip,port* Nếu người nhận không chấp
	 * nhận file thì gửi về người gửi là không nhận file
	 */
	private void processForStartUDPOfClientRequest(Object obj, Socket soc) {
		ObjectOutputStream oos2 = null;
		// ObjectInputStream ois2=null;
		Client client2;
		// 1. nhận đối tượng yêu cầu
		sudocrq = (StartUDPOfClientRequest) obj;
		System.out.println("co yeu cau nhan file " + sudocrq);
		
		// 2. Kiểm tra trong danh sách có người nhận hay không
		client2 = new Client();
		client2.setUserName(sudocrq.getReceiverUserName());
		if (clientIsCurrent(listClient, client2)) {
			// nếu có người nhận
			// 2.1 Tạo yêu cầu khởi động udp
			suosr = new StartUDPOfServerRequest();
			suosr.setFile(sudocrq.getFile());
			suosr.setIpSender(sudocrq.getIpSender());
			suosr.setPortSender(sudocrq.getPortSender());
			// suosr.setNameOfSender(sudocrq.g);
			suosr.setUserNameSender(sudocrq.getSenderUserName());
			suosr.setUserNameReceiver(sudocrq.getReceiverUserName());
			try {
				// 2.2 Gửi yêu cầu khởi động udp của người nhận
				oos2 = new ObjectOutputStream(getSocketInClient(listClient,
						client2).getOutputStream());
				oos2.writeObject(suosr);
				oos2.flush();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Viết ở method khác
			// 2.2 Nhận kết quả yêu cầu khởi động
			// 2.2.1 Nếu không khởi động thì gửi về "người gửi"-> khi o trong
			// function khac là từ chôi
			// 2.2.2 Nếu có khởi động thì gửi về người gửi ip và port của người
			// nhận
		} else {
			// nếu không có người nhận, gửi về người gửi người gửi không online
			try {
				sudocrp = new StartUDPOfClientRespose();
				sudocrp.setOnline(false);
				sudocrp.setUserName(sudocrq.getSenderUserName());
				sudocrp.setReceiver(sudocrq.getReceiverUserName());
				Socket socTemp = getSocketByUserName(listClient,
						sudocrq.getSenderUserName());
				oos2 = new ObjectOutputStream(socTemp.getOutputStream());
				oos2.writeObject(sudocrp);
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	private void processForStartUDPOfStartUDPOfServerRepose(
			StartUDPOfServerRepose svrp) {
		// 2.2 Nhận kết quả yêu cầu khởi động
		// 2.2.1 Nếu không khởi động thì gửi về "người gửi"-> khi o trong
		// function khac là từ chôi
		// 2.2.2 Nếu có khởi động thì gửi về người gửi ip và port của người nhận

		if (svrp.isAccept()) {
			System.out.println("nhận");
			try {
				sudocrp = new StartUDPOfClientRespose();
				sudocrp.setOnline(true);
				sudocrp.setAccept(true);
				sudocrp.setIp(svrp.getIpReceiver());
				sudocrp.setPort(svrp.getPortReceiver());
				sudocrp.setUserName(svrp.getUserNameSender());
				sudocrp.setReceiver(svrp.getReceiver());
				sudocrp.setF(svrp.getF());
				Socket socTemp=new Socket();
				socTemp = getSocketByUserName(listClient,
						svrp.getUserNameSender());
				oos2 = new ObjectOutputStream((socTemp).getOutputStream());
				oos2.writeObject(sudocrp);
				oos2.flush();
				//Không nên xóa
				// Nếu đóng oos2 ở đây thì soc trong arraylist cũng bị đóng, nếu
				// không đóng thì gửi tập tin lần 2 ko đc nên phải copy 1 bản
				// sao của nó trong array để dùng

				System.out.println("Gửi về nhận");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			System.out.println("ko nhận");
			//	ObjectOutputStream oos2;
			try {
				sudocrp = new StartUDPOfClientRespose();
				sudocrp.setOnline(true);
				sudocrp.setAccept(false);
				sudocrp.setUserName(svrp.getUserNameSender());
				sudocrp.setReceiver(svrp.getReceiver());
				Socket socTemp = getSocketByUserName(listClient,
						svrp.getUserNameSender());
				oos2 = new ObjectOutputStream((socTemp)
						.getOutputStream());// Làm soctemp hay tạo 1 array đưa
				// vào rồi tìm ra???
				oos2.writeObject(sudocrp);
				oos2.flush();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			//
		}
	}
public void processStopFromClient(StopSendFromClient st)
{
	Socket socTemp = getSocketByUserName(listClient,
			st.getSender());
	try {
		ObjectOutputStream oosx = new ObjectOutputStream(socTemp.getOutputStream());
		oosx.writeObject(new StopSendFromServer(st.getF(), st.getReceiver()));
		oosx.flush();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	public void run(){
		try {
			// 3. nhận yêu cầu
			ois = new ObjectInputStream(soc.getInputStream());
			obj = ois.readObject();// nhận đối tượng
			System.out.println(obj);
			// 4. xử lý
			if(obj instanceof FriendListRequest)
			{
				FriendListRequest flr=(FriendListRequest)obj;
				FriendsDAO fdao=new FriendsDAO();
				ArrayList<FriendInfo> list=fdao.getAllFriends(flr.getUserName());
				FriendListRepose flrp=new FriendListRepose(list);
				ObjectOutputStream ooxo=new ObjectOutputStream(soc.getOutputStream());
				ooxo.writeObject(flrp);
				ooxo.flush();
			}else if(obj instanceof AddFriendRequest){
				AddFriendRequest ar=(AddFriendRequest)obj;
				FriendsDAO fd=new FriendsDAO();
				boolean x = fd.addFriend(ar.getUserName(), ar.getFriend());
				AddFriendRespose arp=new AddFriendRespose(ar.getUserName(), ar.getFriend(), x);
				ObjectOutputStream oo=new ObjectOutputStream(soc.getOutputStream());
				oo.writeObject(arp);
				oo.flush();
				//gui ve nguoi dc ket ban
				if(x)
				{
					Client cl=new Client();
					cl.setUserName(ar.getFriend());
					if (clientIsCurrent(listClient, cl)) {
						Socket s=getSocketByUserName(listClient, ar.getFriend());
						ObjectOutputStream ox=new ObjectOutputStream(s.getOutputStream());
						AlertAddFriend al=new AlertAddFriend(ar.getUserName());
						ox.writeObject(al);
						ox.flush();
					}
				}
				
			}else if(obj instanceof ResetPassRequest){
				ResetPassRequest rprq=(ResetPassRequest)obj;
				ChatUserDAO cu=new ChatUserDAO();
				String pass=cu.findPassword(rprq.getUserName(), rprq.getEmail());
				SendMail sm=new SendMail(rprq.getEmail(), pass);
				ResetPassRespose rpr=new ResetPassRespose(sm.send());
				ObjectOutputStream oooosss=new ObjectOutputStream(soc.getOutputStream());
				oooosss.writeObject(rpr);
				oooosss.flush();
			}else if(obj instanceof StopSendFromClient){
				StopSendFromClient st=(StopSendFromClient)obj;
				processStopFromClient(st);			
			}else if (obj instanceof StartUDPOfClientRequest) {
				processForStartUDPOfClientRequest(obj, soc);
			}else if (obj instanceof StartUDPOfServerRepose) {
				processForStartUDPOfStartUDPOfServerRepose((StartUDPOfServerRepose) obj);
			}else if (obj instanceof DeleteRequest) {
				clientLogOut((DeleteRequest) obj, listClient);
			}else if (obj instanceof Message) {
				ms = (Message) obj;
				for (Client client : listClient) {
					// the if is never check
					if (client.getSoc() == null || client.getSoc().isClosed()) {
						listClient.remove(client);
					} else if (!client.getUserName().equals(ms.getSender())
							&& client.getUserName().equals(ms.getReceivers())) {
						try {
							oos = new ObjectOutputStream(client.getSoc()
									.getOutputStream());
							oos.writeObject(ms);
							oos.flush();
						} catch (IOException e) {
							client.getSoc().close();
							listClient.remove(client);
						}
					}
				}
			} else if (obj instanceof LoginRequest) {
				System.out.println("yêu cầu đăng nhập");
				lrq = (LoginRequest) obj;
				System.out.println(lrq);
				cud = new ChatUserDAO();
				u = cud.getUser(lrq.getUserName());
				fd = new FriendsDAO();
				if (u != null)
					if (lrq.getUserName().equals(u.getUserName().trim())
							&& lrq.getPassWord().equals(u.getPassWord().trim())) {
						// update ip and port in database
						cud.setIpAndPort(u.getUserName(), soc.getInetAddress()
								.toString().trim(), soc.getPort());
						// /
						client = new Client();
						client.setSoc(soc);
						client.setUserName(lrq.getUserName());
						client.setPassWord(lrq.getPassWord());
						// Neu client dang ton tai thi ngat client cu va tao
						// client moi
						if (clientIsCurrent(getListClient(), client)) {
							removeClient(getListClient(), client);
							getListClient().add(client);// da remove trong
							// clientIsCurrent...
						} else
							getListClient().add(client);
						lrp = new LoginRespose();
						lrp.setU(u);
						lrp.setFriendList(fd.getAllFriends(u.getUserName()
								.trim()));
						oos = new ObjectOutputStream(soc.getOutputStream());
						oos.writeObject(lrp);
						oos.flush();

					} else{
						System.out.println("Sai Pass!");
						oos = new ObjectOutputStream(soc.getOutputStream());
						oos.writeObject(null);
						oos.flush();// tống khứ bộ đệm
					}
				else {
					System.out.println("UserName không tồn tại!");
					oos = new ObjectOutputStream(soc.getOutputStream());
					oos.writeObject(null);
					oos.flush();// tống khứ bộ đệm
				}
			}else if(obj instanceof RegisterRequest){
				ChatUserDAO chatUserDAO = new ChatUserDAO();
				if(chatUserDAO.register(((RegisterRequest) obj).getUsername(), ((RegisterRequest) obj).getName(),
						((RegisterRequest) obj).getPass(), ((RegisterRequest) obj).getEmail())){
					oos = new ObjectOutputStream(soc.getOutputStream());
					oos.writeObject(true);
					oos.flush();
				}else{
					oos = new ObjectOutputStream(soc.getOutputStream());
					oos.writeObject(false);
					oos.flush();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Mot thang da out");
		}
	}
}

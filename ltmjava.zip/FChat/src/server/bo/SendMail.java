package server.bo;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
	private String sendTo,pass;
	public SendMail(String sendTo,String pass) {
		this.sendTo=sendTo;
		this.pass=pass;
	}
	public void send(String smtpServer, String to, String from,
			String psw, String subject, String body) throws Exception {
		Properties props = System.getProperties();
		// –
		props.put("mail.smtp.host", smtpServer);
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.starttls.enable", "true");
		final String login = from;// ”nth001@gmail.com”;//usermail
		final String pwd = psw;// ”password cua ban o day”;
		Authenticator pa = null; // default: no authentication
		if (login != null && pwd != null) { // authentication required?
			props.put("mail.smtp.auth", "true");
			pa = new Authenticator() {
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(login, pwd);
				}
			};
		}// else: no authentication
		Session session = Session.getInstance(props, pa);
		// — Create a new message –
		Message msg = new MimeMessage(session);
		// — Set the FROM and TO fields –
		msg.setFrom(new InternetAddress(from));
		msg.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(to, false));

		// — Set the subject and body text –
		msg.setSubject(subject);
		msg.setText(body);
		// — Set some other header information –
		msg.setHeader("X-Mailer", "LOTONtechEmail");
		msg.setSentDate(new Date());
		msg.saveChanges();
		// — Send the message –
		Transport.send(msg);

	}
public boolean send()
{
	if(pass==null) return false;
	try {
		String smtpServer = "smtp.gmail.com";
		String to = sendTo;
		String from = "vantien1st@gmail.com";
		String subject = "Yêu cầu lấy lại mật khẩu từ FChat";
		String body = "Mật khẩu mới của bạn là: "+pass;
		String password = "05021992";
		send(smtpServer, to, from, password, subject, body);
	} catch (Exception ex) {
		return false;
	}
	return true;
}

}

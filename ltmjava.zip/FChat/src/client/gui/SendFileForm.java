package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.io.File;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class SendFileForm extends JFrame implements Observer{
	private JProgressBar processBar;
	private int percent;
	public SendFileForm(File f,String receiver) {
		percent=0;
		JPanel pn=new JPanel(new BorderLayout());
		JPanel pnTop=new JPanel(new GridLayout(2, 2));
		pnTop.add(new JLabel("Tập tin: "+f.getName()));
		pnTop.add(new JLabel());
		pnTop.add(new JLabel("Người nhận: "+receiver));
		pnTop.add(new JLabel());
		JPanel pnCenter=new JPanel(new BorderLayout());
		pnCenter.add(processBar=new JProgressBar(0, 100),BorderLayout.CENTER);
		processBar.setForeground(Color.BLUE);
		processBar.setStringPainted(true);
		processBar.setString(percent+"%");
		JPanel pnBottom=new JPanel();
		pnBottom.add(new JButton("Hủy"));
		pn.add(pnTop,BorderLayout.NORTH);
		pn.add(pnCenter,BorderLayout.CENTER);
		setTitle("Dang gui tap tin den: "+receiver);
		add(pn);
		setSize(500, 150);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	public void update(Observable arg0, Object arg1) {
		int percent=(int)arg1;
		processBar.setString(percent+"%");
		processBar.setValue(percent);
	
}
}

package client.gui;

public class Controler 
{
	private ChatLoginForm clf;
	public Controler() {
		clf=new ChatLoginForm(this);
		clf.setVisible(true);
	}
	public void restart(){
		clf.setVisible(false);
		clf=new ChatLoginForm(this);
		clf.setVisible(true);
	}
}

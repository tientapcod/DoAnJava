package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import bean.LoginRespose;
import client.bo.ProcessClient;

public class ChatLoginForm extends JFrame implements ActionListener,KeyListener {
	private JMenuBar mnb;
	private JMenu mnChatchitchichoe, mnHelp, mnThemes;
	private JMenuItem mniBlue, mniOrange, mniGreen;
	private JTextField tfUserName;
	private JPasswordField tfPassWord;
	private JButton btLogin, lbRegistry, lbForgotPassWork;
	private Themes themes;
	private Controler cl;
	private ProcessClient pc;
	private Socket soc;
	private Properties pr;
	public ChatLoginForm(Controler cl) {
		pr = new Properties();
		try {
			pr.load(new FileInputStream("configClient.properties"));
		} catch (Exception e) {
			System.out.println("Không load được file " + e);
		}
		this.cl = cl;
		themes = new Themes();
		this.setTitle("Dang nhap FChat");
		this.setSize(300, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setMenubar();
		this.setMainLayout();
	}
	private void setMainLayout(){
		JPanel pn = new JPanel(new BorderLayout());
		pn.add(setLogo(), BorderLayout.NORTH);
		pn.add(setFormLogin(), BorderLayout.CENTER);
		pn.add(setregistry(), BorderLayout.SOUTH);
		this.add(pn);
	}

	private void setMenubar() {
		mnb = new JMenuBar();
		mnb.add(mnChatchitchichoe = new JMenu("FChat"));
		mnb.add(mnHelp = new JMenu("Help"));
		mnChatchitchichoe.setForeground(Color.white);
		mnHelp.setForeground(Color.white);
		mnb.setBackground(Color.DARK_GRAY);
		mnThemes = new JMenu("Giao diện");
		mnThemes.add(mniBlue = new JMenuItem("Màu xanh da trời"));
		mnThemes.add(mniOrange = new JMenuItem("Màu cam"));
		mnThemes.add(mniGreen = new JMenuItem("Màu xanh lá cây"));

		mniBlue.setForeground(Color.decode("#1E90FF"));
		mniOrange.setForeground(Color.decode("#FFA54F"));
		mniGreen.setForeground(Color.decode("#228B22"));
		mnChatchitchichoe.add(mnThemes);
		mniGreen.addActionListener(this);
		mniBlue.addActionListener(this);
		mniOrange.addActionListener(this);
		this.setJMenuBar(mnb);
	}

	private JPanel setLogo() {
		Box b = Box.createVerticalBox();
		BufferedImage myPicture = null;
		try {
			myPicture = ImageIO.read(new File("image/chat.gif"));
		} catch (IOException e) {

		}
		JLabel picLabel = new JLabel(new ImageIcon(myPicture));
		b.add(Box.createVerticalStrut(20));
		b.add(picLabel);
		JPanel pn = new JPanel();
		pn.add(b);
		pn.setBackground(Color.decode(themes.getBgColor()));
		return pn;
	}

	private JPanel setFormLogin() {
		JPanel pn = new JPanel();
		JPanel pnBt=new JPanel(new FlowLayout(FlowLayout.CENTER));
		JPanel pnUserName=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JPanel pnPass=new JPanel(new FlowLayout(FlowLayout.LEFT));
		Box b = Box.createVerticalBox();
		b.add(b.createVerticalStrut(50));
		pnUserName.add(new JLabel("Tên đăng nhập:"));
		b.add(pnUserName);
		b.add(tfUserName = new JTextField(15));
		pnPass.add(new JLabel("Mật khẩu:"));
		b.add(pnPass);
		b.add(tfPassWord = new JPasswordField(15));
		b.add(b.createVerticalStrut(10));
		pnBt.add(btLogin = new JButton("Đăng Nhập"));
		b.add(pnBt);
		btLogin.addActionListener(this);
		pn.add(b);
		pn.setBackground(Color.decode(themes.getBgColor()));
		pnBt.setBackground(Color.decode(themes.getBgColor()));
		pnUserName.setBackground(Color.decode(themes.getBgColor()));
		pnPass.setBackground(Color.decode(themes.getBgColor()));
		tfPassWord.addKeyListener(this);
		tfUserName.addKeyListener(this);
		return pn;
	}

	private JPanel setregistry() {
		JPanel pn = new JPanel();
		Box b = Box.createVerticalBox();
		lbRegistry = new JButton();
		lbRegistry.setText("Đăng ký tài khoản");
		lbRegistry.setHorizontalAlignment(SwingConstants.LEFT);
		lbRegistry.setBorderPainted(false);
		lbRegistry.setOpaque(false);
		lbRegistry.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		lbRegistry.setBackground(Color.lightGray);
		b.add(lbRegistry);
		lbRegistry.addActionListener(this);
		lbForgotPassWork = new JButton("Quên mật khẩu");
		lbForgotPassWork.setHorizontalAlignment(SwingConstants.LEFT);
		lbForgotPassWork.setBorderPainted(false);
		lbForgotPassWork.setOpaque(false);
		lbForgotPassWork.setCursor(new java.awt.Cursor(
				java.awt.Cursor.HAND_CURSOR));
		lbForgotPassWork.setBackground(Color.lightGray);
		b.add(lbForgotPassWork);
		lbForgotPassWork.addActionListener(this);
		pn.add(b);
		pn.setBackground(Color.decode(themes.getBgColor()));
		return pn;
	}
	private void actionForLoginButton()
	{
		try {
			soc = new Socket(pr.getProperty("IPServer"), Integer.parseInt(pr.getProperty("PortServer")));
			pc = new ProcessClient(soc, null);
			LoginRespose lr = pc.conectServerToLogin(tfUserName.getText(),
					new String(tfPassWord.getPassword()));
			if (lr != null) {
				soc.setKeepAlive(true);
				(new ListFriendForm(lr, soc)).setVisible(true);
				this.dispose();
			} else {
				JOptionPane.showMessageDialog(null,
						"Tên đăng nhập hoặc mật khẩu không hợp lệ");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Lỗi kết nối " + e);
			System.out.println("Lỗi đăng nhập " + e);
		}
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btLogin) {
			actionForLoginButton();
		}else if (e.getSource() == lbRegistry) {
			this.setEnabled(false);
			new RegistryForm(this).setVisible(true);
		}else if (e.getSource() == lbForgotPassWork) {
			this.setEnabled(false);
			new FogotPassWordForm(this).setVisible(true);
		}else if (e.getSource() == mniBlue) {
			themes.setBgColor("#1E90FF");
			cl.restart();
		}else if (e.getSource() == mniOrange) {
			themes.setBgColor("#FFA54F");
			cl.restart();
		}else if (e.getSource() == mniGreen) {
			themes.setBgColor("#228B22");
			cl.restart();
		}

	}

	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
		if(arg0.getSource()==tfPassWord || arg0.getSource()==tfUserName)
		{
			if(arg0.getKeyCode()==10)
			{
				actionForLoginButton();
			}

		}

	}

	public void keyReleased(KeyEvent arg0) {
		//
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}
}

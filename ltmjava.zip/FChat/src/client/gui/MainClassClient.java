package client.gui;

public class MainClassClient {
	public static void main(String[] args) {
		new Controler();
	}
}

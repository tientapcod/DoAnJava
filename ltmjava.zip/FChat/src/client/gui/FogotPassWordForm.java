package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Properties;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import bean.ResetPassRequest;
import bean.ResetPassRespose;

public class FogotPassWordForm extends JFrame implements ActionListener {
	private JTextField tfUserName, tfEmail;
	private Themes themes;
	private JButton btGetPassWord, btCancel;
	private ChatLoginForm clf;
	private Properties pr;
	public FogotPassWordForm(ChatLoginForm clf) {
		pr = new Properties();
		try{
			pr.load(new FileInputStream("configClient.properties"));
		}catch (Exception e) {
			System.out.println("Không load được file " + e);
		}
		this.clf = clf;
		themes = new Themes();
		setMainLayout();
		setTitle("Lay lai mat khau");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(300, 700);
		setLocationRelativeTo(null);
	}

	private void setMainLayout() {
		JPanel pn = new JPanel(new BorderLayout());
		pn.add(setLogo(), BorderLayout.NORTH);
		pn.add(setForm(), BorderLayout.CENTER);
		pn.add(new JLabel("Thông tin mật khẩu sẽ được gửi đến mail của bạn "), BorderLayout.SOUTH);
		pn.setBackground(Color.decode(themes.getBgColor()));
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				clf.setEnabled(true);
			}
		});
		this.add(pn);
	}

	private JPanel setForm() {
		JPanel pn = new JPanel();
		Box b = Box.createVerticalBox();
		Box b1 = Box.createHorizontalBox();
		Box b2 = Box.createHorizontalBox();
		Box b3 = Box.createHorizontalBox();
		JLabel lbUserName = new JLabel("Tên đăng nhập: ", Label.RIGHT);
		JLabel lbEmail = new JLabel("Email: ", Label.RIGHT);
		lbEmail.setPreferredSize(lbUserName.getPreferredSize());
		b1.add(lbUserName);
		b1.add(tfUserName = new JTextField());
		b2.add(lbEmail);
		b2.add(tfEmail = new JTextField());
		b3.add(Box.createHorizontalStrut(40));
		b3.add(btGetPassWord = new JButton("Lấy lại mật khẩu"));
		b3.add(Box.createHorizontalStrut(20));
		b3.add(btCancel = new JButton("Hủy"));
		b.add(b1);
		b.add(Box.createVerticalStrut(5));
		b.add(b2);
		b.add(Box.createVerticalStrut(15));
		b.add(b3);
		pn.add(b);
		pn.setBackground(Color.decode(themes.getBgColor()));
		btCancel.addActionListener(this);
		btGetPassWord.addActionListener(this);
		return pn;
	}

	private JPanel setLogo() {
		Box b = Box.createVerticalBox();
		BufferedImage myPicture = null;
		try {
			myPicture = ImageIO.read(new File("image/forgotpass.png"));
		} catch (IOException e) {

		}
		JLabel picLabel = new JLabel(new ImageIcon(myPicture));
		b.add(Box.createVerticalStrut(20));
		b.add(picLabel);
		JPanel pn = new JPanel();
		pn.add(b);
		pn.setBackground(Color.decode(themes.getBgColor()));
		return pn;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btCancel) {
			clf.setEnabled(true);
			this.dispose();
		}
		if (e.getSource() == btGetPassWord) {
			clf.setEnabled(true);
			if (tfUserName.getText().isEmpty() || tfEmail.getText().isEmpty())
				JOptionPane.showMessageDialog(null, "Hãy nhập đầy đủ các trường");
			else {
				//1. Gửi email và userName lên server
				try {
					Socket soc = new Socket(pr.getProperty("IPServer"),
							Integer.parseInt(pr.getProperty("PortServer")));
					ObjectOutputStream oos=new ObjectOutputStream(soc.getOutputStream());
					ResetPassRequest rp=new ResetPassRequest(tfUserName.getText(), tfEmail.getText());
					oos.writeObject(rp);
					oos.flush();
					ObjectInputStream ois=new ObjectInputStream(soc.getInputStream());
					Object obj=ois.readObject();
					if(obj instanceof ResetPassRespose)
					{
						ResetPassRespose rpr=(ResetPassRespose)obj;
						if(rpr.isReset()){
							JOptionPane.showMessageDialog(null, "Mật khẩu mới đã được gửi đến email của bạn!");
							this.dispose();
						}
						else{
							JOptionPane.showMessageDialog(null, "Không thể lấy lại mật khẩu, kiểm tra đường truyền, tên đăng nhập và email!");
						}
							
					}
					
				} catch (Exception e1) {
					System.out.println("Lỗi lấy lại mật khẩu " + e1);
				}
			}
		}
	}

}

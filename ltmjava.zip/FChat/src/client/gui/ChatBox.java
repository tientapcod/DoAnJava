package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import bean.Message;
import client.bo.ChatBoxObserver;
import client.bo.ProcessClient;

public class ChatBox extends JFrame implements ActionListener, KeyListener {
	private JMenuBar mnb;
	private JButton btSendFile, btSend;
	private JTextArea tfText, tfChat;
	private Themes themes;
	private String userNameOfFriend, yourUserName, nameOfFriend, yourName;
	private ChatBoxObserver cbo;
	private ListFriendForm lff;
	private Message ms;
	private ObjectOutputStream oos;
	private Socket soc;
	private Properties pr;
	private JScrollPane jsp;
	private ProcessClient pc;
	private ExecutorService exeCutor=Executors.newFixedThreadPool(50);
	public ChatBox(String userName, String nameOfFriend, ListFriendForm cfd,
			String yourUserName, String yourName) {
		this.lff = cfd;
		this.yourName = yourName;
		this.userNameOfFriend = userName;
		this.nameOfFriend = nameOfFriend;
		this.yourUserName = yourUserName;
		themes = new Themes();
		pc = new ProcessClient(cfd.getSoc(),cfd);
		pr = new Properties();
		try {
			pr.load(new FileInputStream("configClient.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setMenubar();
		setMainLayout();
		cbo = new ChatBoxObserver();
		cbo.addObserver(cfd);

		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				cbo.removeChatBoxFromList(ChatBox.this.userNameOfFriend);
			}
		});

		this.setTitle(userName);
		setSize(500, 600);
		setLocationRelativeTo(lff);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	private void setMainLayout() {
		JPanel pn = new JPanel(new BorderLayout());

		pn.add(setTop(), BorderLayout.NORTH);
		pn.add(setCenter(), BorderLayout.CENTER);
		pn.add(setBottom(), BorderLayout.SOUTH);
		pn.setBackground(Color.decode(themes.getBgColor()));
		Box b = Box.createHorizontalBox();
		b.add(pn);
		// b.add(pnTable);
		this.add(pn);
	}

	public void showMessageNotOnline() {
		JOptionPane
		.showMessageDialog(this, nameOfFriend + " hiện không online");
	}

	public void showMessageNotReiveFile() {
		JOptionPane.showMessageDialog(this, nameOfFriend
				+ " Từ chối tập tin bạn gửi");
	}

	public String getYourName() {
		return yourName;
	}

	public void setYourName(String yourName) {
		this.yourName = yourName;
	}

	public String getNameOfFriend() {
		return nameOfFriend;
	}

	public void setNameOfFriend(String nameOfFriend) {
		this.nameOfFriend = nameOfFriend;
	}

	public String getUserNameOfFriend() {
		return userNameOfFriend;
	}

	public void setUserNameOfFriend(String userNameOfFriend) {
		this.userNameOfFriend = userNameOfFriend;
	}

	public String getYourUserName() {
		return yourUserName;
	}

	public void setYourUserName(String yourUserName) {
		this.yourUserName = yourUserName;
	}

	public JTextArea getTfText() {
		return tfText;
	}

	public void setTfText(JTextArea tfText) {
		this.tfText = tfText;
	}

	public JTextArea getTfChat() {
		return tfChat;
	}

	public void setTfChat(JTextArea tfChat) {
		this.tfChat = tfChat;
	}

	private JPanel setTop() {
		Box ball = Box.createVerticalBox();
		Box b = Box.createHorizontalBox();

		b.add(Box.createHorizontalStrut(10));
		b.add(btSendFile = new JButton("Gửi tập tin"));
		b.add(Box.createHorizontalStrut(10));
		JPanel pn = new JPanel(new BorderLayout());
		ball.add(Box.createVerticalStrut(20));

		JPanel pnb = new JPanel(new BorderLayout());
		pnb.setBackground(Color.decode(themes.getBgColor()));
		pnb.add(b);
		ball.add(pnb);
		ball.add(Box.createVerticalStrut(10));
		JPanel pnlable = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlable.add(new JLabel(nameOfFriend));
		ball.add(pnlable);
		pnlable.setBackground(Color.decode(themes.getBgColor()));
		pn.add(ball, BorderLayout.NORTH);
		pn.setBackground(Color.decode(themes.getBgColor()));
		btSendFile.addActionListener(this);
		return pn;
	}

	private JPanel setCenter() {
		JPanel pn = new JPanel(new BorderLayout());
		Box b = Box.createHorizontalBox();
		jsp = new JScrollPane(new JScrollPane(tfText = new JTextArea()));
		b.add(Box.createHorizontalStrut(3));
		b.add(jsp, BorderLayout.CENTER);
		b.add(Box.createHorizontalStrut(3));
		pn.add(b);
		tfText.setLineWrap(true);
		tfText.setEditable(false);
		pn.setBackground(Color.decode(themes.getBgColor()));
		return pn;
	}

	private Box setBottom() {
		Box ball = Box.createVerticalBox();
		ball.add(Box.createVerticalStrut(10));
		JPanel pn = new JPanel(new BorderLayout());
		Box btf = Box.createHorizontalBox();
		btf.add(new JScrollPane(tfChat = new JTextArea(3, 10)), BorderLayout.CENTER);
		pn.add(btf);
		btf.add(Box.createHorizontalStrut(3));
		tfChat.setLineWrap(true);
		pn.add(btSend = new JButton("Gửi"), BorderLayout.EAST);
		Box b = Box.createHorizontalBox();
		b.add(Box.createHorizontalStrut(3));
		b.add(pn);
		b.add(Box.createHorizontalStrut(3));
		ball.add(b);
		ball.add(Box.createVerticalStrut(3));
		btSend.addActionListener(this);
		tfChat.addKeyListener(this);
		tfChat.setFocusable(true);
		addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent e) {
				tfChat.requestFocus();
			}
		});
		return ball;
	}

	private void setMenubar() {
		mnb = new JMenuBar();
		mnb.add(new JMenu("FChat"));
		mnb.add(new JMenu("Help"));
		mnb.setBackground(Color.lightGray);
		this.setJMenuBar(mnb);
	}

	public String getUserName() {
		return userNameOfFriend;
	}

	private void actionForSendMessage() {
		ms = new Message();
		ms.setSender(yourUserName);
		ms.setReceivers(userNameOfFriend);
		ms.setContains(tfChat.getText());
		ms.setNameOfSender(yourName);
		if(ms.getContains() != null){
			tfText.append(yourName + " (Tôi): " + tfChat.getText());
			tfText.append("\n");
			tfChat.setText(null);
		}
		
		try {
			soc = new Socket(pr.getProperty("IPServer"), Integer.parseInt(pr.getProperty("PortServer")));
			oos = new ObjectOutputStream(soc.getOutputStream());
			oos.writeObject(ms);
			oos.flush();
			oos.close();
			soc.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btSend) {
			actionForSendMessage();		
		}else if (arg0.getSource() == btSendFile) {
			final ChatBox cb=this;
			exeCutor.execute(new Runnable() {
				
				@Override
				public void run() {
					JFileChooser fileChooser = new JFileChooser();
					fileChooser.setDialogTitle("Chon tap tin muon gui");
					fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
					int i=fileChooser.showOpenDialog(cb);
					if(i==JFileChooser.APPROVE_OPTION)
					{
						File file = fileChooser.getSelectedFile();
						pc.sendFile(file, yourUserName,lff.getYourPassWord(), userNameOfFriend, cb);
					}
					
				}
			});
			
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {

		if (e.getSource() == tfChat) {
			if (e.getKeyCode() == 10 || e.getKeyCode() == 13) {
				actionForSendMessage();
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}
}

package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Properties;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import bean.AddFriendRequest;
import bean.AddFriendRespose;
import bean.DeleteRequest;
import bean.FriendInfo;
import bean.FriendListRepose;
import bean.FriendListRequest;
import bean.LoginRespose;
import bean.Message;
import client.bo.ProcessClient;

public class ListFriendForm extends JFrame implements ActionListener,
		MouseListener, Observer {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JMenuBar mnb;
	private JMenu mnChatchitchichoe, mnHelp;
	private JMenuItem singout;
	private JButton btAddFriend;
	private JTextField tfAddFriend;
	private DefaultTableModel dtm;
	private JTable table;
	private Themes themes;
	private JLabel lb;
	private ChatLoginForm clf;
	private JMenuItem mniLogout, mniExit,mniDocument;
	private LoginRespose lr;
	private ProcessClient pc;
	private ArrayList<ChatBox> cbList;
	private ChatBox cb;
	private Socket soc;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private Message m;
	private String yourPassWord;
	private JFileChooser fileChooser;
	private Properties pr;
	public ListFriendForm(final LoginRespose lr, Socket soc) {
		pr = new Properties();
		try{
			pr.load(new FileInputStream("configClient.properties"));
		}catch(Exception e) {
			System.out.println("Không load được file " + e);
		}
		this.soc = soc;
		this.yourPassWord=lr.getU().getPassWord();
		themes = new Themes();
		lb = new JLabel("Chào " + lr.getU().getName(), JLabel.LEFT);
		pc = new ProcessClient(this.soc, this);
		cbList = new ArrayList<ChatBox>();
		this.lr = lr;
		this.setTitle(lr.getU().getName());
		this.setSize(300, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setMenubar();
		this.setMainLayout();
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				DeleteRequest dr = new DeleteRequest(lr.getU().getUserName(),
						lr.getU().getPassWord());
				try {
					Socket soc2 = new Socket(
							pc.getPr().getProperty("IPServer"), Integer
									.parseInt(pc.getPr().getProperty(
											"PortServer")));
					oos = new ObjectOutputStream(soc2.getOutputStream());
					oos.writeObject(dr);
					oos.flush();
					oos.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				// waitAndReceiveFromServer();
				pc.waitAndReceiveFromServer(ListFriendForm.this.soc, cbList,
						ListFriendForm.this, cb, lr);
			}
		});
		t.start();
	}

	public String getYourPassWord() {
		return yourPassWord;
	}

	public void setYourPassWord(String yourPassWord) {
		this.yourPassWord = yourPassWord;
	}

	private void setMainLayout() {
		JPanel pn = new JPanel(new BorderLayout());
		pn.add(setTop(), BorderLayout.NORTH);
		pn.add(setCenter(), BorderLayout.CENTER);
		pn.add(setBottom(), BorderLayout.SOUTH);
		pn.setBackground(Color.decode(themes.getBgColor()));
		this.add(pn);
	}

	private void setMenubar() {
		mnb = new JMenuBar();
		mnb.add(mnChatchitchichoe = new JMenu("FChat"));
		mnChatchitchichoe.add(singout=new JMenuItem("Thoát"));
		mnb.add(mnHelp = new JMenu("Help"));
		mnChatchitchichoe.setForeground(Color.white);
		mnHelp.setForeground(Color.white);
		mnb.setBackground(Color.DARK_GRAY);
		singout.addActionListener(this);
		this.setJMenuBar(mnb);
	}

	private Box setTop() {
		Box b = Box.createVerticalBox();
		Box b1 = Box.createHorizontalBox();
		JPanel pn = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pn.add(lb);
		lb.setForeground(Color.white);
		b1.add(Box.createHorizontalStrut(10));
		b1.add(new JLabel("Nick: "));
		b1.add(tfAddFriend = new JTextField(10));
		b1.add(Box.createHorizontalStrut(5));
		b1.add(btAddFriend = new JButton("Thêm bạn"));
		b1.add(Box.createHorizontalStrut(10));
		b.add(Box.createVerticalStrut(20));
		b.add(b1);
		b.add(Box.createVerticalStrut(10));
		b.add(pn);
		pn.setBackground(Color.decode(themes.getBgColor()));
		b.setBackground(Color.decode(themes.getBgColor()));
		btAddFriend.addActionListener(this);
		return b;
	}
	public File showDiaglogSaveFile(String fileName)
	{
		fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Chon vi tri luu tap tin");    
		File fileToSave=new File(fileName); 
		fileChooser.setSelectedFile(fileToSave);
		int userSelection = fileChooser.showSaveDialog(this);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    fileToSave = fileChooser.getSelectedFile();
		}
		return fileToSave;
	}
	private void waitAndReceiveFromServer() {
		while (!soc.isClosed()) {
			try {
				ObjectInputStream ois2 = new ObjectInputStream(
						soc.getInputStream());
				Object obj = ois2.readObject();
				if (obj instanceof Message) {
					m = (Message) obj;
					pc.showInChatBox(m, cbList, this, cb, lr);
				}
			} catch (IOException e) {
				if (e instanceof EOFException) {
					JOptionPane
							.showMessageDialog(this,
									"Có người đăng nhập tài khoản của bạn. Chương trình sẽ thoát!");
					System.exit(0);
				}
				if (e instanceof SocketException) {
					JOptionPane
							.showMessageDialog(this,
									"Lỗi kết nối. Bạn vui lòng kiểm tra lại kết nối!");
					System.exit(0);
				}
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// }
		}
	}

	private Box setCenter() {
		JPanel pn = new JPanel(new BorderLayout());
		dtm = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		dtm.addColumn("Danh sách bạn bè");
		for (FriendInfo fd : lr.getFriendList()) {
			String row[] = { pc.showInRow(fd) };
			dtm.addRow(row);
		}

		table = new JTable(dtm);
		table.addMouseListener(this);
		table.setSelectionBackground(Color.black);
		table.setSelectionForeground(Color.white);
		pn.add(new JScrollPane(table));
		Box b = Box.createHorizontalBox();
		b.add(Box.createHorizontalStrut(3));
		b.add(pn);
		b.add(Box.createHorizontalStrut(3));
		pn.setBackground(Color.decode(themes.getBgColor()));
		return b;
	}

	private Box setBottom() {
		Box b = Box.createVerticalBox();
		b.add(Box.createVerticalStrut(30));
		b.setBackground(Color.decode(themes.getBgColor()));
		return b;
	}

	public Socket getSoc() {
		return soc;
	}

	public void setSoc(Socket soc) {
		this.soc = soc;
	}
	public void reLoadFriend()
	{
		int rowCount=dtm.getRowCount();
		for(int i=0;i<rowCount;i++)
		{
			dtm.removeRow(0);
		}
		////
		Socket soc;
		try {
			soc = new Socket(pr.getProperty("IPServer"),
					Integer.parseInt(pr.getProperty("PortServer")));
			ObjectOutputStream ooooo=new ObjectOutputStream(soc.getOutputStream());
			FriendListRequest fr=new FriendListRequest(lr.getU().getUserName());
			ooooo.writeObject(fr);
			ooooo.flush();
			ObjectInputStream ii=new ObjectInputStream(soc.getInputStream());
			Object obj=ii.readObject();
			if(obj instanceof FriendListRepose)
			{
				FriendListRepose flr=(FriendListRepose)obj;
				ArrayList<FriendInfo> ar=flr.getList();
				for (FriendInfo f : ar) {
					String row[] = { pc.showInRow(f) };
					dtm.addRow(row);
				}
			}
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btAddFriend) {
			
			if(tfAddFriend.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Nhập nick name muốn kết bạn");
			}
			{
				//1. Gửi yêu cầu kết bạn
				try {
					Socket soc = new Socket(pr.getProperty("IPServer"),
							Integer.parseInt(pr.getProperty("PortServer")));
					AddFriendRequest af=new AddFriendRequest(lr.getU().getUserName(),tfAddFriend.getText());
					ObjectOutputStream oooo=new ObjectOutputStream(soc.getOutputStream());
					oooo.writeObject(af);
					oooo.flush();
					ObjectInputStream iiii=new ObjectInputStream(soc.getInputStream());
					Object obj=iiii.readObject();
					if(obj instanceof AddFriendRespose){
						AddFriendRespose arp=(AddFriendRespose)obj;
						if(arp.isSuccess()){
							JOptionPane.showMessageDialog(this, "Đã kết bạn với "+af.getFriend()+" thành công");
							reLoadFriend();
						}
						else
							JOptionPane.showMessageDialog(this, "Không thể kết bạn với "+af.getFriend());
					}
				} catch (NumberFormatException | IOException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}else if (e.getSource() == singout)
		{	
			System.exit(0);
		}

	}

	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == table) {
			if (e.getClickCount() == 2) {
				String nameShow = dtm.getValueAt(table.getSelectedRow(), 0)
						.toString().trim();
				if (!pc.checkChatBoxIsCurrent(cbList,
						pc.parsertoGetUserName(nameShow))) {
					cb = new ChatBox(pc.parsertoGetUserName(nameShow),
							pc.parseTogetName(nameShow), this, lr.getU()
									.getUserName(), lr.getU().getName());
					cbList.add(cb);
					cb.setVisible(true);
				}
			}
		}
	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void update(Observable arg0, Object arg1) {
		pc.removeChatBox(cbList, (String) (arg1));

	}
}

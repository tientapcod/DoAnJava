package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

import client.bo.StopReceiveFileObserver;


public class ReceiveFileForm extends JFrame implements ActionListener, Observer {

	private JButton btCancle;
	private JProgressBar processBar;
	private int percent;
	private StopReceiveFileObserver srf;
	public ReceiveFileForm(File f,String sender,final StopReceiveFileObserver srf) {
		this.srf=srf;
		percent = 0;
		JPanel pn = new JPanel(new BorderLayout());
		JPanel pnTop = new JPanel(new GridLayout(2, 2));
		pnTop.add(new JLabel("Tập tin: "));
		pnTop.add(new JLabel(f.getName()));
		pnTop.add(new JLabel("Người gửi:  "));
		pnTop.add(new JLabel(sender));
		JPanel pnCenter = new JPanel(new BorderLayout());
		pnCenter.add(processBar = new JProgressBar(0, 100), BorderLayout.CENTER);
		processBar.setForeground(Color.BLUE);
		processBar.setStringPainted(true);
		processBar.setString(percent + "%");
		JPanel pnBottom = new JPanel();
		pnBottom.add(btCancle = new JButton("Hủy"));
		pn.add(pnTop, BorderLayout.NORTH);
		pn.add(pnCenter, BorderLayout.CENTER);
		btCancle.addActionListener(this);
		add(pn);
		setTitle("Dang nhan tap tin tu: "+sender);
		setSize(500, 150);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				srf.stop();
			}
		});
	}

	public StopReceiveFileObserver getSrf() {
		return srf;
	}

	public void setSrf(StopReceiveFileObserver srf) {
		this.srf = srf;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource()==btCancle)
		{
			srf.stop();
		}

	}

	@Override
	public void update(Observable o, Object arg) {
		int percent = (int) arg;
		System.out.println(percent);
		if (percent <= 100) {
			processBar.setString(percent + "%");
			processBar.setValue(percent);
		}
	}
}

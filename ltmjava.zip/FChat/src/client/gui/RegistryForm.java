package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Properties;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import client.bo.ProcessClient;

public class RegistryForm extends JFrame implements ActionListener
{
	private JTextField tfUserName,tfEmail,tfName;
	private JPasswordField tfPassWord,tfRePassWord;
	private JButton btRegistry,btCancel;
	private Themes themes;
	private ChatLoginForm clf;
	private Properties pr;
	private ProcessClient pc;
	public RegistryForm(ChatLoginForm clf) {
		pr = new Properties();
		try {
			pr.load(new FileInputStream("configClient.properties"));
		} catch (Exception e) {
			System.out.println("Không load được file " + e);
		}
		this.clf=clf;
		themes=new Themes();
		this.setTitle("Dang ky tai khoan");
		setMainLayout();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(300, 700);
		setLocationRelativeTo(null);
	}
	private void setMainLayout() {
		JPanel pn = new JPanel(new BorderLayout());
		pn.add(setLogo(),BorderLayout.NORTH);
		pn.add(setRegistryForm(), BorderLayout.CENTER);
		this.add(pn);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				clf.setEnabled(true);
			}
		});
	}
	private JPanel setRegistryForm(){
		JLabel lbUserName=new JLabel("Tên đăng nhập: ",Label.RIGHT);
		JLabel lbPassWord=new JLabel("Mật khẩu: ",Label.RIGHT);
		JLabel lbRePassWord=new JLabel("Nhập lại mật khẩu: ",Label.RIGHT);
		JLabel lbName=new JLabel("Tên của bạn: ",Label.RIGHT);
		JLabel lbEmail=new JLabel("Địa chỉ Email: ",Label.RIGHT);
		Box b1=Box.createHorizontalBox();
		Box b2=Box.createHorizontalBox();
		Box b3=Box.createHorizontalBox();
		Box b4=Box.createHorizontalBox();
		Box b5=Box.createHorizontalBox();
		Box b6=Box.createHorizontalBox();

		
		Box b=Box.createVerticalBox();
		b1.add(lbUserName);
		b1.add(new JPanel().add(tfUserName=new JTextField(15)));
		b2.add(lbPassWord);
		b2.add(tfPassWord=new JPasswordField(15));
		b3.add(lbRePassWord);
		b3.add(tfRePassWord=new JPasswordField(15));
		b4.add(lbName);
		b4.add(tfName=new  JTextField(15));
		b5.add(lbEmail);
		b5.add(tfEmail=new JTextField(15));
		b6.add(btRegistry=new JButton("Đăng ký"));
		b6.add(Box.createHorizontalStrut(15));
		b6.add(btCancel=new JButton("Hủy"));
		btCancel.addActionListener(this);
		b.add(b1);
		b.add(Box.createVerticalStrut(5));
		b.add(b2);
		b.add(Box.createVerticalStrut(5));
		b.add(b3);
		b.add(Box.createVerticalStrut(5));
		b.add(b4);
		b.add(Box.createVerticalStrut(5));
		b.add(b5);
		b.add(Box.createVerticalStrut(5));
		b.add(b6);
		lbPassWord.setPreferredSize(lbUserName.getPreferredSize());
		lbRePassWord.setPreferredSize(lbUserName.getPreferredSize());
		lbEmail.setPreferredSize(lbUserName.getPreferredSize());
		lbName.setPreferredSize(lbUserName.getPreferredSize());
		JPanel pn=new JPanel();
		pn.setBackground(Color.decode(themes.getBgColor()));
		pn.add(b);
		btRegistry.addActionListener(this);
		return pn;
	}
	private JPanel setLogo()
	{
		Box b=Box.createVerticalBox();
		BufferedImage myPicture = null;
		try {
			myPicture = ImageIO.read(new File("image/re.gif"));
		} catch (IOException e) {
		
		}
		JLabel picLabel = new JLabel(new ImageIcon(myPicture));
		b.add(Box.createVerticalStrut(20));
		b.add(picLabel);
		JPanel pn=new JPanel();
		pn.add(b);
		pn.setBackground(Color.decode(themes.getBgColor()));
		return pn;
	}
	
	/**
	 * kiem tra email
	 * @param email
	 * @return
	 */
	public boolean isEmail(String email) {
		if ("".equals(email))
			return true;
		else {
			String emailPattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-z]{2,7}$";
			return Pattern.matches(emailPattern, email);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btCancel){
			clf.setEnabled(true);
			this.dispose();
		}
		if(e.getSource()==btRegistry){


			String pass = new String(tfPassWord.getPassword());
			String repass = new String(tfRePassWord.getPassword());
			if ("".equals(tfUserName.getText()))
				JOptionPane.showMessageDialog(null, "Tên đăng nhập không hợp lệ!");
			else if (tfUserName.getText().length() > 10)
				JOptionPane.showMessageDialog(null, "Tên đăng nhập không quá 10 ký tự");
			else if ("".equals(pass))
				JOptionPane.showMessageDialog(null, "Mật khẩu không được để trống!");
			else if (pass.length() > 10)
				JOptionPane.showMessageDialog(null, "Độ dài mật khấu không quá 10 ký tự!");
			else if ("".equals(repass))
				JOptionPane.showMessageDialog(null, "Mật khẩu nhập lại không được để trống!");
			else if (!pass.equals(repass))
				JOptionPane.showMessageDialog(null, "Mật khẩu nhập lại không đúng!");
			else if("".equals(tfName.getText()))
				JOptionPane.showMessageDialog(null, "Họ và tên không được để trống!");
			else if (tfName.getText().length() > 50)
				JOptionPane.showMessageDialog(null, "Họ và tên không hợp lệ!");
			else if (tfEmail.getText().length() > 30 || !isEmail(tfEmail.getText()))
				JOptionPane.showMessageDialog(null, "Địa chỉ email không hợp lệ!");
			else{
				try {
					Socket soc = new Socket(pr.getProperty("IPServer"), Integer.parseInt(pr.getProperty("PortServer")));
					pc = new ProcessClient(soc, null);
					if(pc.conectServerToRegis(tfUserName.getText().trim(), tfName.getText().trim(), pass, tfEmail.getText().trim())){
						JOptionPane.showMessageDialog(null, "Đăng ký thành công!");
						this.dispose();
						clf.setEnabled(true);
					} else {
						JOptionPane.showMessageDialog(null, "Đăng ký thất bại. Tên đăng nhập đã tồn tại!");
						this.dispose();
						clf.setEnabled(true);
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Có lỗi trong quá trình đăng ký " + e2);
					this.dispose();
					clf.setEnabled(true);
				}
			}
		}
		
	}
}

package client.gui;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Themes{
	private String bgColor;

	public Themes(){
		//
	}

	public String getBgColor() {
		Properties prop = new Properties();
		FileInputStream f = null;
		try {
			f = new FileInputStream("config.properties");
			prop.load(f);
			bgColor = prop.getProperty("bgColor");

		} catch (IOException ex) {
			bgColor = "#F1EFE2";
		} finally {
			try {
				f.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bgColor;
	}

	public void setBgColor(String bgColor) {
		Properties prop = new Properties();
		try {
			prop.setProperty("bgColor", bgColor);
			prop.store(new FileOutputStream("config.properties"), null);

		} catch (IOException ex) {
			ex.printStackTrace();
		}	
		this.bgColor = bgColor;
	}

}

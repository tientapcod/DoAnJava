package client.bo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Observable;
import java.util.Properties;

import bean.StopSendFromClient;


public class StopReceiveFileObserver extends Observable{
	private Properties pr;
	private String sender,receiver;
	private File f;
	public StopReceiveFileObserver(String sender,File f,String receiver) {
		this.sender=sender;
		this.f=f;
		this.receiver=receiver;
		pr = new Properties();
		try {
			pr.load(new FileInputStream("configClient.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void stop()
	{
		setChanged();
		notifyObservers();
		stopSend();
		// gửi lên server kêu người gửi đừng gửi nữa
	}
	private void stopSend()
	{
		try {
			Socket soc= new Socket(pr.getProperty("IPServer"),
					Integer.parseInt(pr.getProperty("PortServer")));
			//Gửi hủy lên server
			ObjectOutputStream oos=new ObjectOutputStream(soc.getOutputStream());
			oos.writeObject(new StopSendFromClient(sender,f,receiver));
			oos.flush();
			oos.close();
			
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public File getF() {
		return f;
	}
	public void setF(File f) {
		this.f = f;
	}
	
	
	
}


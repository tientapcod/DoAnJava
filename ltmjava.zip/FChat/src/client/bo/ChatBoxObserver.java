	package client.bo;

import java.util.Observable;

public class ChatBoxObserver extends Observable{
	public ChatBoxObserver() {
		// TODO Auto-generated constructor stub
	}
	public void removeChatBoxFromList(String userName)
	{
		setChanged();
		notifyObservers(userName);
	}

}

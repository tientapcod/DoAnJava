package client.bo;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JOptionPane;

import bean.AlertAddFriend;
import bean.FriendInfo;
import bean.LoginRequest;
import bean.LoginRespose;
import bean.Message;
import bean.RegisterRequest;
import bean.StartUDPOfClientRequest;
import bean.StartUDPOfClientRespose;
import bean.StartUDPOfServerRepose;
import bean.StartUDPOfServerRequest;
import client.gui.ChatBox;
import client.gui.ListFriendForm;

public class ProcessClient extends Observable {
	private Socket soc, socSendFile;
	private ObjectOutputStream oos, oos2;
	private ObjectInputStream ois;
	private Properties pr;
	private StartUDPOfClientRequest sudcrq;
	private Message m;
	private StartUDPOfServerRequest suosrq;
	private ExecutorService exeCutor=Executors.newFixedThreadPool(1000);
	public ProcessClient(Socket soc, ListFriendForm lff) {
		this.soc = soc;
		pr = new Properties();
		try {
			pr.load(new FileInputStream("configClient.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}

	public Properties getPr() {
		return pr;
	}

	public void setPr(Properties pr) {
		this.pr = pr;
	}

	public boolean checkChatBoxInList(Message ms, ArrayList<ChatBox> cbList) {
		for (ChatBox cb : cbList) {
			if (cb.getUserNameOfFriend().equals(ms.getSender())) {
				cb.getTfText().append(cb.getNameOfFriend() + " : ");
				cb.getTfText().append(ms.getContains());
				cb.getTfText().append("\n");
				return true;
			}
		}
		return false;
	}

	public boolean checkInFriendList(Message m, LoginRespose lr) {
		for (FriendInfo fi : lr.getFriendList()) {
			if (fi.getUserName().equals(m.getReceivers()))//nguoi nhan
				return true;
		}
		return false;
	}
	
	private void send(File f, int portSend,String hostReceive, int portReceiv,String receiver){
		SendFileRunable send=new SendFileRunable(f, portSend, hostReceive, portReceiv,receiver);
		Thread t=new Thread(send);
		t.start();
	}
	public void waitAndReceiveFromServer(Socket soc, final ArrayList<ChatBox> cbList,
			final ListFriendForm lff, final ChatBox cb, final LoginRespose lr) {
		while (!soc.isClosed()) {
			try {
				ObjectInputStream ois2 = new ObjectInputStream(
						soc.getInputStream());
				final Object obj = ois2.readObject();
				if(obj instanceof AlertAddFriend)
				{
					AlertAddFriend al=(AlertAddFriend)obj;
					JOptionPane.showMessageDialog(null, al.getNameAdd()+" đã kết bạn với bạn");
					lff.reLoadFriend();
				}
				if (obj instanceof StartUDPOfClientRespose) {
					StartUDPOfClientRespose suocrp = (StartUDPOfClientRespose) obj;
					//cong gui
					System.out.println(suocrp.getIp()+" "+suocrp.getPort()+" "+suocrp.getReceiver());
					if (!suocrp.isOnline()) {
						// thông báo không online
						JOptionPane.showMessageDialog(null,suocrp.getReceiver() + " hiện không trực tuyến");
						//cb.showMessageNotOnline();
					} else {
						if (suocrp.isAccept()) {
							System.out.println("Người nhận đã chuẩn bị nhận file");
							try {
								Thread.sleep(500);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							//cong 6543 la cong send
							send(suocrp.getF(),6543,suocrp.getIp(), suocrp.getPort(),suocrp.getReceiver());
						} else {
							JOptionPane.showMessageDialog(null,suocrp.getReceiver()+ " đã từ chối nhận tập tin của bạn");
						}
					}
				}
				if (obj instanceof Message) {
					exeCutor.execute(new Runnable() {
						
						@Override
						public void run() {
							m = (Message) obj;
							showInChatBox(m, cbList, lff, cb, lr);
							
						}
					});
				}
				if (obj instanceof StartUDPOfServerRequest) {
					exeCutor.execute(new Runnable() {	
						@Override
						public void run() {
							suosrq = (StartUDPOfServerRequest) obj;
							System.out.println("Nhận đc 1 yêu cầu mở udp " + suosrq.getIpSender()+" "+suosrq.getNameOfSender()+" "+suosrq.getPortSender()+" "+suosrq.getUserNameReceiver() +suosrq.getFile());
							// Hiện hộp thoại thông báo có nhận hay không
							// Nếu nhận thì hiện bảng lưu file và gửi chấp nhận hiển thị
							// form chuyển file
							// Nếu không thì gửi từ chối

							int dialogResult = JOptionPane.showConfirmDialog(lff,
									suosrq.getUserNameSender()
									+ " đang gửi cho bạn 1 tập tin có tên: "
									+ suosrq.getFile().getName() + "\n"
									+ "Dung lượng: "
									+ suosrq.getFile().getUsableSpace()
									+ " bytes", "Nhận tập tin",
									JOptionPane.YES_NO_OPTION);
							Socket socSvRp = null;
							try {
								socSvRp = new Socket(pr.getProperty("IPServer"),
										Integer.parseInt(pr.getProperty("PortServer")));
							} catch (Exception e) {
								System.out.println("Lỗi mở cổng nhận file " + e);
							}
							if (dialogResult == 0) {
								// nhận
								File f=lff.showDiaglogSaveFile(suosrq.getFile().getName());		
								StartUDPOfServerRepose suosrp2 = new StartUDPOfServerRepose();
								suosrp2.setAccept(true);
								suosrp2.setUserNameSender(suosrq.getUserNameSender());
								//Khởi động udp	
								suosrp2.setIpReceiver("localhost");
								//cong nhan file
								suosrp2.setPortReceiver(8888);
								suosrp2.setReceiver(suosrq.getUserNameReceiver());
								suosrp2.setF(suosrq.getFile());
								ObjectOutputStream oos2;
								try {
									oos2 = new ObjectOutputStream(socSvRp.getOutputStream());
									oos2.writeObject(suosrp2);
									oos2.flush();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								Thread t=new Thread(new ReceiveFileRunable(f, 8888,suosrq.getFile(),suosrq.getUserNameSender(),suosrq.getUserNameReceiver()));
								t.start();
							} else {
								StartUDPOfServerRepose suosrp2 = new StartUDPOfServerRepose();
								suosrp2.setUserNameSender(suosrq.getUserNameSender());
								suosrp2.setAccept(false);
								suosrp2.setReceiver(suosrq.getUserNameReceiver());
								ObjectOutputStream oos2;
								try {
									oos2 = new ObjectOutputStream(socSvRp.getOutputStream());
									oos2.writeObject(suosrp2);
									oos2.flush();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
								//	oos2.close();
								System.out.println("Gửi lên server là ko nhan");
							}
							
						}
					});


				}
			} catch (IOException e) {
				if (e instanceof EOFException) {
					e.printStackTrace();
					JOptionPane
					.showMessageDialog(lff,
							"Có người đã đăng nhập tài khoản của bạn, chương trình thoát");
					System.exit(0);
				}
				if (e instanceof SocketException) {
				//	e.printStackTrace();
					JOptionPane
					.showMessageDialog(lff,
							"Kết nối bị đứt, chương trình thoát. Bạn vui lòng kiểm tra lại kết nối");
					System.exit(0);
				}
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// }
		}
	}
	public void showInChatBox(Message m, ArrayList<ChatBox> cbList,
			ListFriendForm lff, ChatBox cb, LoginRespose lr) {
		if(m.getContains() != null){
			if (!checkChatBoxInList(m, cbList)) {
				cb = new ChatBox(m.getSender(), m.getNameOfSender(), lff, lr.getU()
						.getUserName(), lr.getU().getName());
				cb.getTfText().append(cb.getNameOfFriend() + " : ");
				cb.getTfText().append(m.getContains());
				cb.getTfText().append("\n");
				cbList.add(cb);
				cb.setVisible(true);
			}
		}
		
	}

	public Socket getSoc() {
		return soc;
	}

	public void setSoc(Socket soc) {
		this.soc = soc;
	}
	public boolean removeChatBox(ArrayList<ChatBox> cbList, String userName) {
		for (int i = 0; i < cbList.size(); i++) {
			if (cbList.get(i).getUserName().equals(userName)) {
				cbList.remove(i);
				return true;
			}
		}
		return false;
	}

	public String showInRow(FriendInfo fd) {
		String row;
		row = fd.getName() + "(" + fd.getUserName() + ")";
		return row;
	}

	public String parsertoGetUserName(String row) {
		StringBuffer userName = new StringBuffer();
		// int i=row.length()-2;// sub for 2 because: length() and location of
		// char is difference, last char is )
		for (int i = row.length() - 2; i > 0; i--) {
			if (row.charAt(i) != '(') {
				userName.append(row.charAt(i));
			} else
				break;
		}
		userName = userName.reverse();
		return new String(userName);
	}

	public String parseTogetName(String row) {
		StringBuffer name = new StringBuffer();
		for (int i = 0; i < row.length(); i++) {
			if (row.charAt(i) != '(')
				name.append(row.charAt(i));
			else
				break;
		}
		return name.toString();
	}
	
	/* Mở cổng
	 * Gửi lên server thông tin gửi bao gồm: sender, passsender,file,receiver 
	 * */
	public void sendFile(File f,String sender,String passSender,String receiver,ChatBox cb)
	{
		try {
			socSendFile = new Socket(pr.getProperty("IPServer"),
					Integer.parseInt(pr.getProperty("PortServer")));
			sudcrq = new StartUDPOfClientRequest(f, sender,passSender,
					receiver);
			oos2 = new ObjectOutputStream(socSendFile.getOutputStream());
			oos2.writeObject(sudcrq);
			oos2.flush();
		} catch (Exception e) {
			System.out.println("Lỗi phương thức sendFile " + e);
		}
		
	}
	public boolean checkChatBoxIsCurrent(ArrayList<ChatBox> cbList,
			String userName) {

		for (ChatBox cb : cbList) {
			if (cb.getUserName().equals(userName)) {
				return true;
			}
		}
		return false;
	}

	public LoginRespose conectServerToLogin(String userName, String passWord) {
		LoginRequest login;
		LoginRespose respose = null;
		try {
			login = new LoginRequest();
			login.setUserName(userName);
			login.setPassWord(passWord);
			oos = new ObjectOutputStream(soc.getOutputStream());
			oos.writeObject(login);
			ois = new ObjectInputStream(soc.getInputStream());
			Object obj = ois.readObject();// nhận đối tượng
			if (obj instanceof LoginRespose) {
				respose = (LoginRespose) obj;
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Không thể kết nối đến máy chủ, vui lòng kiểm tra lại kết nối của bạn");
		} catch (ClassNotFoundException e) {
			System.out.println("Lỗi conectServerToLogin " + e);
		}
		return respose;
	}

	public boolean conectServerToRegis(String userName, String name,
			String pass, String email) {
		RegisterRequest regis = new RegisterRequest(userName, pass, email, name);
		try {
			oos = new ObjectOutputStream(soc.getOutputStream());
			oos.writeObject(regis);
			oos.flush();
			ois = new ObjectInputStream(soc.getInputStream());
			return (Boolean)ois.readObject();
		} catch (IOException e) {
			System.out.println(" loi ket noi conectServerToRegis " + e);
		}catch(ClassNotFoundException e){
			System.out.println("loi doc du lieu conectServerToRegis " + e);
		}
		return false;
	}
}

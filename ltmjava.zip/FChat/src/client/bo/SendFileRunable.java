package client.bo;

import java.io.File;
import java.io.FileInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Observable;

import client.gui.SendFileForm;


public class SendFileRunable extends Observable implements Runnable{

	public volatile boolean stop = false;
	private File f;
	private int port;
	private String hostReceive,receiver;
	private int portReceiv;
	public SendFileRunable(File f, int portSend,String hostReceive, int portReceiv,String receiver) {
		this.f=f;
		this.port=portSend;
		this.hostReceive=hostReceive;
		this.portReceiv=portReceiv;
		this.receiver=receiver;
	}
	@Override
	public void run() {
		DatagramSocket socsendFile;
		SendFileForm sff=new SendFileForm(f,receiver);
		sff.setVisible(true);
		this.addObserver(sff);
		try {
			socsendFile = new DatagramSocket(port);
			DatagramPacket packet;
			byte []buffer=new byte[512];	
			int nob=0;
			if(f.exists())
			{
				System.out.println(f.exists());
				FileInputStream fis=new FileInputStream(f);
				float fsize=0;
				float bytes = f.length();
				while((nob=fis.read(buffer))!=-1)
				{
					System.out.println(!stop);
					fsize+=512;
					float mylong=(fsize/bytes)*100;
					int per=Math.round(mylong);
					setChanged();
					notifyObservers(per);
					packet=new DatagramPacket(buffer,nob,InetAddress.getByName(hostReceive),portReceiv);
					socsendFile.send(packet);
					Thread.sleep(10);
				}
				fis.close();
			}
			//gửi tín hiệu kết thúc
			byte buf[]="!!!!111@@@###".getBytes();
			packet=new DatagramPacket(buf, buf.length,InetAddress.getByName(hostReceive),portReceiv);
			socsendFile.send(packet);
			try{Thread.sleep(50);}catch(Exception ex){ex.printStackTrace();}
			socsendFile.close();
			socsendFile.disconnect();
			stop=true;
			sff.setVisible(false);
		} catch (Exception e) {
			System.out.println("Lỗi khi send file " + e);
		}

	}
	public void stop()
	{
		stop = true;
	}



}

package client.bo;

import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Observable;

import client.gui.ReceiveFileForm;

public class ReceiveFileRunable extends Observable implements Runnable{
	private volatile boolean stop = false;
	private File f,fsend;
	private int port;
	private ReceiveFileForm rff;
	private StopReceiveFileObserver stopRF;
	private PercentProcessBar ppb;
	private String sender,receiver;
	public ReceiveFileRunable(File f, int portReceiv,File fsend,String sender,String receiver) {
		this.sender=sender;
		this.f=f;
		this.receiver=receiver;
		this.port=portReceiv;
		this.fsend=fsend;
		// TODO Auto-generated constructor stub
	}
	@Override
	public void run() {
		System.out.println("Đang chờ nhận file");
		ppb=new PercentProcessBar();
		stopRF=new StopReceiveFileObserver(sender,f,receiver);
		rff=new ReceiveFileForm(fsend,sender,stopRF);
		rff.setVisible(true);
		ppb.addObserver(rff);
	//	stopRF.addObserver(this);
		DatagramSocket socFile;
		float bytes = fsend.length();
		try {			
			socFile = new DatagramSocket(port);
			byte[] data = new byte[512];
			DatagramPacket packet;
			FileOutputStream fos = new FileOutputStream(f);
			int offset = 512;
			float fsize=0;
			while (offset == 512 && !stop) {
				fsize+=512;
				float mylong=(fsize/bytes)*100;
				int per=Math.round(mylong);
				ppb.changePercent(per);
				packet = new DatagramPacket(data, data.length);
				socFile.receive(packet);// packet chứa dữ liệu
				String s = new String(packet.getData()).trim();
				if (s.equals("!!!!111@@@###")) {// Nhan tin hieu ket thuc gui
					if (f.length() == 0) { // neu khong nhan duoc thi xoa file
						fos.close();
						f.delete();
					}
					break;
				}
				fos.write(packet.getData(), 0, packet.getLength());
				fos.flush();
				Thread.sleep(4);
				data = new byte[512];
				offset = packet.getLength();
				System.out.println("đang nhận...");
			}
			System.out.println("finish");
			fos.close();
			stop=true;
			socFile.close();
			socFile.disconnect();
		} catch (Exception e) {
			System.out.println("Lỗi receive file " + e);
		}
		rff.dispose();	
	}
	
	public void stop()
	{
		stop=true;
	}
}

package client.bo;

import java.util.Observable;

public class PercentProcessBar extends Observable{
public PercentProcessBar() {
	// TODO Auto-generated constructor stub
}
public void changePercent( int percent)
{
	setChanged();
    notifyObservers(percent);
}
}

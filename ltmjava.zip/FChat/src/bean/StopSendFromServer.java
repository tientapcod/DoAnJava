package bean;

import java.io.File;
import java.io.Serializable;

public class StopSendFromServer implements Serializable{
	private File f;
	private String receiver;
	public StopSendFromServer(File f,String receiver) {
		this.f = f;
		this.receiver = receiver;
	}
	public File getF() {
		return f;
	}
	public void setF(File f) {
		this.f = f;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	

}

package bean;

import java.io.File;
import java.io.Serializable;

public class StartUDPOfServerRepose implements Serializable{
	private String ipReceiver;
	private File f;
	private String userNameSender,receiver;
	private int portReceiver;
	private boolean accept;
	public String getIpReceiver() {
		return ipReceiver;
	}
	public void setIpReceiver(String ipReceiver) {
		this.ipReceiver = ipReceiver;
	}
	public int getPortReceiver() {
		return portReceiver;
	}
	public void setPortReceiver(int portReceiver) {
		this.portReceiver = portReceiver;
	}
	public boolean isAccept() {
		return accept;
	}
	public void setAccept(boolean accept) {
		this.accept = accept;
	}
	public String getUserNameSender() {
		return userNameSender;
	}
	public void setUserNameSender(String userNameSender) {
		this.userNameSender = userNameSender;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public File getF() {
		return f;
	}
	public void setF(File f) {
		this.f = f;
	}
	
}

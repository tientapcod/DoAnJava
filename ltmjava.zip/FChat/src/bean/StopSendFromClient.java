package bean;

import java.io.File;
import java.io.Serializable;

public class StopSendFromClient implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sender,receiver;
	private File f;
	public StopSendFromClient(String sender,File f,String receiver) {
		this.sender = sender;
		this.f = f;
		this.receiver = receiver;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public File getF() {
		return f;
	}
	public void setF(File f) {
		this.f = f;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	
}

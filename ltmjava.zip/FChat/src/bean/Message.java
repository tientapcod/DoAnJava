package bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Message implements Serializable{
	private String sender;
	private String nameOfSender;
	private String contains;
	private String receivers;
	
	public Message(){
		//
	}
	
	public Message(String sender, String nameOfSender, String contains, String receivers){
		this.sender = sender;
		this.nameOfSender = nameOfSender;
		this.contains = contains;
		this.receivers = receivers;
	}
	
	public String getSender() {
		return sender;
	}
	
	public void setSender(String sender) {
		this.sender = sender;
	}
	
	public String getContains() {
		return contains;
	}
	
	public void setContains(String contains) {
		this.contains = contains;
	}
	
	public String getReceivers() {
		return receivers;
	}
	
	public void setReceivers(String receivers) {
		this.receivers = receivers;
	}
	
	public String getNameOfSender() {
		return nameOfSender;
	}
	
	public void setNameOfSender(String nameOfSender) {
		this.nameOfSender = nameOfSender;
	}

	
}

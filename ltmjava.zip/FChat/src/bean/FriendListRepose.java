package bean;

import java.io.Serializable;
import java.util.ArrayList;

public class FriendListRepose implements Serializable{
	
	private ArrayList<FriendInfo> list;
	
	public FriendListRepose(ArrayList<FriendInfo> list) {
		this.list = list;
	}
	
	public ArrayList<FriendInfo> getList() {
		return list;
	}
	
	public void setList(ArrayList<FriendInfo> list) {
		this.list = list;
	}

}

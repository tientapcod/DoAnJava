package bean;

import java.io.File;
import java.io.Serializable;

public class StartUDPOfServerRequest implements Serializable{
	private String userNameSender,nameOfSender,userNameReceiver, ipSender;
	private int portSender;
	private File file;
	public String getUserNameSender() {
		return userNameSender;
	}
	
	public String getNameOfSender() {
		return nameOfSender;
	}

	public void setNameOfSender(String nameOfSender) {
		this.nameOfSender = nameOfSender;
	}

	public void setUserNameSender(String userNameSender) {
		this.userNameSender = userNameSender;
	}
	public String getUserNameReceiver() {
		return userNameReceiver;
	}
	public void setUserNameReceiver(String userNameReceiver) {
		this.userNameReceiver = userNameReceiver;
	}
	public String getIpSender() {
		return ipSender;
	}
	public void setIpSender(String ipSender) {
		this.ipSender = ipSender;
	}

	public int getPortSender() {
		return portSender;
	}
	public void setPortSender(int portSender) {
		this.portSender = portSender;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}

}

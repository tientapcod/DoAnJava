package bean;

import java.io.Serializable;

/**
 * gui yeu cau login
 * @author
 * userName
 * passWord
 *
 */
public class LoginRequest implements Serializable
{
	private String userName;
	private String passWord;
	
	public LoginRequest() {
		//
	}
	
	public LoginRequest(String userName, String password){
		this.userName = userName;
		this.passWord = password;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassWord() {
		return passWord;
	}
	
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	
}

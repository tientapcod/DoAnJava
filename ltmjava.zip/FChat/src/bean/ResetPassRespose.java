package bean;

import java.io.Serializable;

public class ResetPassRespose implements Serializable {
	private boolean reset;
	
	public ResetPassRespose(boolean reset) {
		this.reset = reset;
	}
	
	public boolean isReset() {
		return reset;
	}
	
	public void setReset(boolean reset) {
		this.reset = reset;
	}
	

}

package bean;

import java.io.Serializable;

public class AlertAddFriend implements Serializable{
	private String nameAdd;

	public AlertAddFriend(String nameAdd) {
		this.nameAdd = nameAdd;
	}

	public String getNameAdd() {
		return nameAdd;
	}

	public void setNameAdd(String nameAdd) {
		this.nameAdd = nameAdd;
	}
	

}

package bean;

import java.io.File;
import java.io.Serializable;

public class StartUDPOfClientRespose implements Serializable{
	private String ip,userName,receiver;
	private int port;
	private boolean isAccept=false,isOnline=false;
	private File f;
	
	public StartUDPOfClientRespose(){
		//
	}
	
	public StartUDPOfClientRespose(String ip, String userName, String receiver, int port, File f){
		this.ip = ip;
		this.userName = userName;
		this.receiver = receiver;
		this.port = port;
		this.f = f;
	}
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public boolean isAccept() {
		return isAccept;
	}
	public void setAccept(boolean isAccept) {
		this.isAccept = isAccept;
	}
	public boolean isOnline() {
		return isOnline;
	}
	public void setOnline(boolean isOnline) {
		this.isOnline = isOnline;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public File getF() {
		return f;
	}
	public void setF(File f) {
		this.f = f;
	}
	

	
	
}

package bean;

import java.io.Serializable;

public class AddFriendRequest implements Serializable{
	private String userName,friend;
	
	public AddFriendRequest(String userName,String friend){
		this.userName=userName;
		this.friend=friend;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getFriend() {
		return friend;
	}
	
	public void setFriend(String friend) {
		this.friend = friend;
	}
	
}

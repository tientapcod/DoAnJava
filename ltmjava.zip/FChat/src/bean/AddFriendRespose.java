package bean;

import java.io.Serializable;

public class AddFriendRespose implements Serializable{
	String userName,friend;
	boolean success;
	
	public AddFriendRespose(String userName,String friend,boolean success) {
		this.success=success;
		this.userName=userName;
		this.friend=friend;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getFriend() {
		return friend;
	}
	
	public void setFriend(String friend) {
		this.friend = friend;
	}
	
	public boolean isSuccess() {
		return success;
	}
	
	public void setSuccess(boolean success) {
		this.success = success;
	}
	
}

package bean;

import java.io.File;
import java.io.Serializable;

public class StartUDPOfClientRequest implements Serializable{
	private File file;
	private String senderUserName;
	private String senderPassWord;
	private String receiverUserName;
	private String ipSender;
	private int portSender;
	public StartUDPOfClientRequest(File file,String senderUserName,String senderPassWord,String receiverUserName) {
		this.file = file;
		this.senderPassWord = senderPassWord;
		this.senderUserName = senderUserName;
		this.receiverUserName = receiverUserName;
	}

	public String getSenderPassWord() {
		return senderPassWord;
	}

	public void setSenderPassWord(String senderPassWord) {
		this.senderPassWord = senderPassWord;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getSenderUserName() {
		return senderUserName;
	}
	public void setSenderUserName(String senderUserName) {
		this.senderUserName = senderUserName;
	}
	public String getReceiverUserName() {
		return receiverUserName;
	}
	public void setReceiverUserName(String receiverUserName) {
		this.receiverUserName = receiverUserName;
	}
	public String getIpSender() {
		return ipSender;
	}
	public void setIpSender(String ipSender) {
		this.ipSender = ipSender;
	}
	public int getPortSender() {
		return portSender;
	}
	public void setPortSender(int portSender) {
		this.portSender = portSender;
	}

}

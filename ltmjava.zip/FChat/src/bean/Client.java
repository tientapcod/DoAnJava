package bean;

import java.net.Socket;

public class Client {
	private String userName;
	private String passWord;
	private Socket soc;
	public Client() {
		// TODO Auto-generated constructor stub
	}
	
	public Client(String userName, String passWord, Socket soc) {
		this.userName = userName;
		this.passWord = passWord;
		this.soc = soc;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Socket getSoc() {
		return soc;
	}
	public void setSoc(Socket soc) {
		this.soc = soc;
	}

}

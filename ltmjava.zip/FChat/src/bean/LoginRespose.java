package bean;

import java.io.Serializable;
import java.util.ArrayList;

public class LoginRespose implements Serializable{
	private User u;
	private ArrayList<FriendInfo> friendList;
	
	public LoginRespose() {
		//
	}
	
	public LoginRespose(User u, ArrayList<FriendInfo> friendList){
		this.u = u;
		this.friendList = friendList;
	}
	public User getU() {
		return u;
	}
	
	public void setU(User u) {
		this.u = u;
	}
	
	public ArrayList<FriendInfo> getFriendList() {
		return friendList;
	}
	
	public void setFriendList(ArrayList<FriendInfo> friendList) {
		this.friendList = friendList;
	}
	
	

}
